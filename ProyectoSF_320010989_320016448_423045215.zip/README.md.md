# Proyecto Final – Optimización de Portafolios

App cuantitativa desarrollada en Streamlit para análisis de:
- Portafolios arbitrarios
- Optimización moderna (MPT)
- Black–Litterman

## Ejecutar
